#include <stdio.h>
void main(){
	int arr1[5] = {1,2,3,4,5};
	int arr2[5] = {5,6,7,8,9};
        int arr3[12];
	for(int i=0;i<5;i++){
		arr3[i] = arr1[i];
	}
	int n = 5;
	for(int i=0;i<5;i++){
		arr3[n++] = arr2[i];
	}
	for(int i=0;i<10;i++){
		printf("%d\n",arr3[i]);
	}

}
