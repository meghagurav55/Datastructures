//functions in C
#include <stdio.h>
int evenOdd(int);				//fuction declaration
/*function declaration must end with a semi colon
  If function is not declared then it gives "Warning".
  But it gives correct Output 
*/
void main(){
	int num, flag;
	printf("Enter the number : ");
	scanf("%d",&num);
	flag = evenOdd(num);			//function call
	 
	if(flag == 1)
		printf("%d is Even.\n",num);
	else
		printf("%d is Odd.\n",num);
}

int evenOdd(){				//function header

	//function body
	if(a % 2 == 0)			
		return 1;
	else
		return 0;
}
