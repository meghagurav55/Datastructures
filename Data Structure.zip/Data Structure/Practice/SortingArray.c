//ascending order
#include <stdio.h>
void main(){
	int arr[] = {1,2,3,5,4};
	int arr2[5];
	int t = arr[4];
	for(int i=0;i<5;i++){
		if(t > arr[i]){
			arr2[i] = arr[i];
		}else{
			arr2[i] = t;
		}
	}
	for(int i=0;i<5;i++)
		printf("%d\n",arr2[i]);
}
