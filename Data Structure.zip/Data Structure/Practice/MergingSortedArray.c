#include <stdio.h>
void main(){
	int in1=0,in2=0, n1,n2;
	printf("Enter the elements of array 1 : ");
	scanf("%d",&n1);
	printf("Enter the elements of array 2 : ");
	scanf("%d",&n2);
	int arr1[n1],arr2[n2],arr3[n1+n2];
	printf("Enter the elements of array 1 : ");
	for(int i=0;i<n1;i++){
		scanf("%d",&arr1[i]);
	}
	printf("Enter the elements of array 2 : ");
	for(int i=0;i<n2;i++){
		scanf("%d",&arr2[i]);
	}

	int index=0
	int tot = n1+n2;
	
	while(in1 < n1 && in2 < n2){
		if(arr1[i] > arr2[i]){
			arr3[i] = arr2[i]
			in1++;
		}else{
			arr3[i] == arr1[i];
			in2++;
		}
		index++;
	}

	if(in1 == n1){
		while(in2 < n2){
			
		}
	}


}
