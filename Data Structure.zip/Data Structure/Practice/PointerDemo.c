//pointer demo
#include <stdio.h>
void main(){
	int num, *pnum;
	pnum = &num;
	printf("Enter the number : ");
	scanf("%d",&num);							//2
	printf("The number that was entered is : %d\n",*pnum);			//2
	printf("The number that was entered is : %d\n",*(&num));		//2
	num = &(*pnum);
	printf("num : %p\n",num);						//address
	printf("pnum : %p\n",pnum);						//address
	
	int* ptr,num2=2;

	printf("num 2 : %d\n",&num);						//2

	int num1;
	ptr = num;	/////ERROR
	printf("ptr after assigning 2 : %d\n",ptr);				//garbage value	
}		
