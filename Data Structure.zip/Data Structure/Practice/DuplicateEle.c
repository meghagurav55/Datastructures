#include <stdio.h>
void main(){
	int arr[8] = {1,2,4,6,7,8,3,5};
	int flag=1;
	for(int i=0;i<8;i++){
		for(int j=0;j<8;j++){
			if(arr[i] == arr[j] && i!=j){
				flag=0;
				printf("Duplicte element found at %d \n",i);
			}
		}
	}
	if(flag == 1)
		printf("No duplicate elements found\n");
}
