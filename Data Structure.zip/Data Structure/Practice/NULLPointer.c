//NULL Pointer 
#include <stdio.h>
void main(){
	/*int *ptr;				
					
	printf("%d\n",*ptr);*/
	//statements above reultss in segmentation fault (core dump)	
	
	int *ptr;
	ptr = NULL;
	printf("%d\n",ptr);					//0
	printf("%d\n",&ptr);					//addreess off ptr/
}
