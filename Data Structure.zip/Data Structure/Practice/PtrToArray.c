//Pointer to array
#include <stdio.h>
void main(){
	int arr[] = {1,2,3,4,5};
	int *ptr;
	ptr = &arr[0];
	printf("Your base address is : %p\n",arr);
	///base address of array will be printed

	printf("Elements of array with there base addresses are : ");
	for(int i=0;i<5;i++){
		printf("%p : %d\n",ptr,*ptr);
		ptr++;
	}

	ptr = &arr[0];
	//ptr = &arr asa dila tr warning yete assignment for incompatile typr pointer

	ptr = ptr + 3;
	printf("\nThird element of array is : %d\n",*ptr);		//4

	printf("arr[1] : %d\n",arr[1]);					//2
	printf("i[arr] : %d\n",1[arr]);					//2
	printf("2[arr] : %d\n",2[arr]);					//3
	printf("*(arr+1) : %d\n",*(arr+1));				//2
	printf("*(1+arr) : %d\n",*(1+arr));				//2

	printf("Size of(arr) : %ld\n",(sizeof(arr)));			//20
	printf("Size of (arr[0]) : %ld\n",(sizeof(arr[0])));		//4

}
