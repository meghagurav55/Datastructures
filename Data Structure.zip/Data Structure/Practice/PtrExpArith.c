//Pointer expression and arithmetic
#include <stdio.h>
void main(){
	int num1 = 2,num2 = 3,sum = 0,mul = 0, div = 1;
	int *ptr1,*ptr2;
	ptr1 = &num1;
	ptr2 = &num2;
	sum = *ptr1 + *ptr2;						//sum = 2 + 3 = 5
	printf("Sum : %d\n",sum);					//5
	mul = sum * (*ptr1);						//10
	printf("Mul : %d\n",mul);					//10
	*ptr2 +=1;


	printf("Value at %p is %d\n",&ptr2,*ptr2);			//address : 4
	printf("Value at %p is %d\n",ptr2,*ptr2);			//address : 4
	printf("Value at %p is %d\n",&num2,num2);			//address : 4

	div = 9 + (*ptr1)/(*ptr2) - 30;
	printf("Div  : %d\n",div);					//-21

	/**
	 * int *ptr1 :
	 * mhnje ptr1 asa navacha box tayar honar
	 * int num1=2;
	 * mhnje num1 navacha box tayar honar tyat 2 hi value janar
	 * ptr1 = &num1 :
	 * mhnje ptr1 variable madhe num1 variable cha address janar
	 * printf("%p"&ptr1) : 
	 * mhnje ptr1 box cha address print honar
	 * printf("%p"ptr1) : 
	 * mhnje ptr1 madhe jo num1 cha address gela ahe toh print honar */

}
