/*Pointer increment and decrement
 */
#include <stdio.h>
void main(){
	int num = 2, *ptr;
	ptr = &num;
	int num1 = 4
	printf("Value @ address %p is %d\n",ptr,*ptr);
	
	printf("Address of num is %d\n",&num);				//some address
	//%d format specifier ha num vcha address decimal format madhe print karnya sathi dila ahe
	//ashane warning yete

	*ptr++;							
	/*
	 * This statemnt will be evaluated as *(ptr++ )
	 * "*" operator has lower precedence than that of ++
	 * first : ptr++  --->  ptr = ptr + 1;
	 * next : *ptr;
	 * */
	
	printf("Address in ptr is %d\n",ptr);				//some address + 1byte
	//%d format specifier ha num vcha address decimal format madhe print karnya sathi dila ahe
	//ashane warning yete

	//++ operator increments the memory space by 1byte
	
	printf("Address in ptr is %d and value is %d\n",ptr,*ptr);				//some address + 1byte

	
}
