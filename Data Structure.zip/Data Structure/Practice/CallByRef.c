//Call by reference 

void swap_value(int, int);
void swap_ref1(int*, int*);
#include <stdio.h>
 

void main(){

	int a = 1, b = 2, c1 = 3, d1 = 4;

	printf("In main() a = %d & b = %d\n",a,b);
	swap_value(a,b);	
	printf("In main() a = %d & b = %d\n",a,b);

	printf("In main() c = %d & d = %d\n",c1,d1);
	swap_ref1(&c1,&d1);	
	printf("In main() c = %d & d = %d\n",c1,d1);
}
void swap_value(int a,int b){
	int temp;
	temp = a;
	a = b;
	b = temp;
	printf("In swap_value() a = %d & b = %d\n",a,b);
}
void swap_ref1(int *c,int *d){
	int temp;
	temp = *c;
	*c = *d;
	*d = temp;
	printf("In swap_ref() c = %d & d = %d\n",*c,*d);
}

