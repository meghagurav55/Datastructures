//Pointer to Pointer
#include <stdio.h>
void main(){
	int x = 10;
	int *px, **ppx, ***pppx ;
	px = &x;
	ppx = &px;
	pppx = &ppx;

	printf("Address of x : %p\n",&x);
	printf("Address of x : %p\n",px);
	printf("Address of px : %p\n",ppx);
	printf("Address of ppx : %p\n",pppx);

	printf("The value of x : %d\n",***pppx);
}
