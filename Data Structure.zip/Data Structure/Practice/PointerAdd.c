//Addition of two numbers using pointer


#include <stdio.h>
void sum(int*, int*, int*);
void main(){
	int num1,num2,total;
	printf("Enter the first number : ");
	scanf("%d",&num1);
	printf("Enter the second number : ");
	scanf("%d",&num2);
	sum(&num1,&num2,&total);
	printf("Total = %d\n",total);
}
void sum(int *a,int *b,int *t){
	*t = *a + *b;
}
