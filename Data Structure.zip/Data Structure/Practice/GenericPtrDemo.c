//Generic Pointer
//void pointer demo

#include <stdio.h>
void main(void){
	/*int n=1;
	char c='A';
	int *ptr;
	ptr = &n;
	printf("Ptr pointing to int num : %d\n",*(int*)ptr);
	
	ptr = &c;						//warning : assignment from incompatible pointer type
	printf("Ptr pointing to int num : %c\n",*(char*)ptr);	//A
	*/

	int n=1;
	char c='A';
	void *ptr;
	ptr = &n;
	printf("Ptr pointing to int num : %d\n",*(int*)ptr);
	
	ptr = &c;						//no warning because the pointer is declared as void.
	printf("Ptr pointing to int num : %c\n",*(char*)ptr);	//A
	///void pointer ha kadhihi kontyahi type chya variable la point karu shkto
	//Note : void* should always be type casted if used
}
