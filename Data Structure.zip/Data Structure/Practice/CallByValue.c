#include <stdio.h>
void add(int);			//function declaration
void main(){
	int num = 5;
	printf("Value of number before add(): %d\n",num);		//5
	add(num-1);
	printf("Value of number after add(): %d\n",num);		///5
}
/*
 * Call by value he easy ahe karan apn data value kinwa expression madhe direct pathvu shakto
 * Jitya vela apn function call kru titkya vel copy variable chi copy tayar hote.
 * Copying calling variable value in called function is time consuming ani hach 
 * */
void add(int n){
	n = n + 10;
	printf("Value of number in called function : %d\n",n);		///14
}
